package com.coding.task.domain

import java.util.regex.Pattern

class EmailValidator : FormValidator<String?> {

    override fun invoke(data: String?): ValidationResult {
        return when {
            data.isNullOrEmpty() -> ValidationResult(isValid = false, errorMessage = "The email can't be blank")
            !Pattern.compile(EMAIL_ADDRESS).matcher(data).matches() -> ValidationResult(isValid = false, errorMessage = "That's not a valid email")
            else -> ValidationResult(isValid = true)
        }
    }

    companion object {
        const val EMAIL_ADDRESS = "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}\\@[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}(\\.[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25})+"
    }
}