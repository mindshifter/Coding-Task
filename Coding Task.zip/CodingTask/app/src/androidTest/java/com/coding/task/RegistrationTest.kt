package com.coding.task

import android.content.Context
import android.content.Intent
import androidx.test.core.app.ApplicationProvider
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.*
import com.coding.task.utils.toPrettyDate
import org.hamcrest.CoreMatchers
import org.hamcrest.Matchers
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.text.SimpleDateFormat
import java.util.*


/**
 * Instrumented test, which will execute on an Android device.
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */

const val PACKAGE = "com.coding.task"
const val LAUNCH_TIMEOUT = 3000L

@RunWith(AndroidJUnit4::class)
class RegistrationTest {

    private lateinit var device: UiDevice

    @Before
    fun setUp() {
        device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation())
        val launcherPackage = device.launcherPackageName
        ViewMatchers.assertThat(launcherPackage, CoreMatchers.notNullValue())
        device.wait(Until.hasObject(By.pkg(launcherPackage).depth(0)), LAUNCH_TIMEOUT)
        val context = ApplicationProvider.getApplicationContext<Context>()
        val intent = context.packageManager.getLaunchIntentForPackage(PACKAGE)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
        }
        context.startActivity(intent)
        device.wait(Until.hasObject(By.pkg(PACKAGE).depth(0)), LAUNCH_TIMEOUT)
    }

    @Test
    fun completeRegistrationFormWithData() {
        onView(withId(R.id.nameEditText)).perform(typeText("John Doe"))
        onView(withId(R.id.emailEditText)).perform(typeText("john@doe.ch"))
        onView(withId(R.id.dateOfBirthEditText)).perform(click())
        val dateTo: Date = Calendar.getInstance(TimeZone.getTimeZone("GMT"))
            .apply { set(1984, 6, 30) }.time
        setDate(dateTo)
        val registerButton: UiObject = device.findObject(UiSelector().resourceId("$PACKAGE:id/register_button"))
        registerButton.click()
        onView(withText("John Doe")).check(matches(isDisplayed()))
        onView(withText("john@doe.ch")).check(matches(isDisplayed()))
        onView(withText(dateTo.toPrettyDate())).check(matches(isDisplayed()))
    }

    private fun setDate(date: Date) {
        onView(withTagValue(Matchers.`is`("TOGGLE_BUTTON_TAG" as Any))).perform(click())
        onView(withId(com.google.android.material.R.id.mtrl_picker_text_input_date)).perform(TextInputLayoutActions.replaceText(date.toMaterialCalendarFormat()))
        onView(withTagValue(Matchers.`is`("CONFIRM_BUTTON_TAG" as Any))).perform(click())
    }
}

private fun Date.toMaterialCalendarFormat(pattern: String = "MM/dd/YY"): String = SimpleDateFormat(pattern, Locale.getDefault()).format(this)