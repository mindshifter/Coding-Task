package com.coding.task.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.doOnTextChanged
import androidx.navigation.fragment.findNavController
import com.coding.task.R
import com.coding.task.databinding.FragmentRegistrationBinding
import com.coding.task.domain.ErrorEvent.*
import com.coding.task.utils.clearError
import com.coding.task.viewmodel.RegistrationViewModel
import com.google.android.material.datepicker.CalendarConstraints
import com.google.android.material.datepicker.MaterialDatePicker
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.util.*

class RegisterFragment : BaseFragment<FragmentRegistrationBinding>() {
    override val bindingInflater: (LayoutInflater, ViewGroup?, Boolean) -> FragmentRegistrationBinding = FragmentRegistrationBinding::inflate
    private val registrationViewModel: RegistrationViewModel by viewModel()
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        with(binding) {
            dateOfBirthEditText.setOnClickListener {
                showBirthdayDialog()
            }
            registerButton.setOnClickListener {
                registrationViewModel.register()
            }
            registrationViewModel.registerFail observeOnce {
                when (it) {
                    is NameError -> nameTextInput.error = it.result.errorMessage
                    is EmailError -> emailTextInput.error = it.result.errorMessage
                    is BirthdayError -> dateOfBirthInput.error = it.result.errorMessage
                }
            }

            nameEditText.doOnTextChanged { text, _, _, _ ->
                nameTextInput.clearError()
                registrationViewModel.name = text.toString().trim()
            }
            emailEditText.doOnTextChanged { text, _, _, _ ->
                emailTextInput.clearError()
                registrationViewModel.email = text.toString().trim()
            }
            registrationViewModel.birthdayChanged observe {
                binding.dateOfBirthInput.clearError()
                binding.dateOfBirthEditText.setText(it)
            }
            registrationViewModel.registerSuccess observeOnce {
                findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
            }
        }
    }

    @SuppressLint("RestrictedApi")
    private fun showBirthdayDialog() {
        val calendarConstraints = CalendarConstraints.Builder()
            .setFirstDayOfWeek(Calendar.MONDAY)
            //Uncomment this to disable calendar dates range in  MaterialDatePickerBirthdayDateValidator range
            //.setValidator(MaterialDatePickerBirthdayDateValidator())
            .build()
        val dateRangePicker = MaterialDatePicker.Builder.datePicker()
            .setTitleText("Select date")
            .setSelection(registrationViewModel.dateOfBirth)
            .setCalendarConstraints(calendarConstraints)
            .build()
        dateRangePicker.addOnPositiveButtonClickListener(registrationViewModel::setBirthday)
        dateRangePicker.show(parentFragmentManager, "dateRangePicker")
    }
}