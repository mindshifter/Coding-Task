package com.coding.task.domain

import java.util.*

class BirthdayValidator : FormValidator<Long?> {
    companion object {
        val dateFrom: Date = Calendar.getInstance(TimeZone.getTimeZone("GMT"))
            .apply { set(1900, 0, 0) }.time
        val dateTo: Date = Calendar.getInstance(TimeZone.getTimeZone("GMT"))
            .apply { set(2019, 11, 31) }.time
    }

    override fun invoke(data: Long?): ValidationResult {
        return when (data) {
            null, !in dateFrom.time..dateTo.time -> ValidationResult(isValid = false, errorMessage = "Must be a valid date between Jan 1, 1900 and December 31, 2019.")
            else -> ValidationResult(isValid = true)
        }
    }
}