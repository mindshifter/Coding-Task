package com.coding.task.model

import kotlinx.serialization.Serializable

@Serializable
data class User(
    val name: String? = null,
    val email: String? = null,
    val dateOfBirth: Long? = null,
)
