package com.coding.task.domain

class NameValidator : FormValidator<String?> {
    override fun invoke(data: String?): ValidationResult {
        return when {
            data.isNullOrEmpty() -> ValidationResult(isValid = false, errorMessage = "The name can't be blank")
            data.length == 1 -> ValidationResult(isValid = false, errorMessage = "Must contain more than one character")
            else -> ValidationResult(isValid = true)
        }
    }
}