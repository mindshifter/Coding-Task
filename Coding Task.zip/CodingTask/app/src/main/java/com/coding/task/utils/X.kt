package com.coding.task.utils

import com.google.android.material.textfield.TextInputLayout
import java.text.SimpleDateFormat
import java.util.*

fun TextInputLayout.clearError() {
    error = null
    isErrorEnabled = false
}

fun Date.toPrettyDate(pattern: String = "dd/MM/yyyy"): String = SimpleDateFormat(pattern, Locale.getDefault()).format(this)
