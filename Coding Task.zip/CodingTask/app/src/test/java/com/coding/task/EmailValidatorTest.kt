package com.coding.task

import com.coding.task.domain.EmailValidator
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class EmailValidatorTest {
    private lateinit var emailValidator: EmailValidator

    @Before
    fun setUp() {
        emailValidator = EmailValidator()
    }

    @Test
    fun `Correct Email Simple, Returns True`() = assertTrue(emailValidator("name@email.com").isValid)

    @Test
    fun `Correct Email Sub Domain, Returns True`() = assertTrue(emailValidator("name@email.co.uk").isValid)

    @Test
    fun `Invalid Email No Top Level Domain, Returns False`() = assertFalse(emailValidator("name@email").isValid)

    @Test
    fun `Invalid Email Double Dot, Returns False`() = assertFalse(emailValidator("name@email..com").isValid)

    @Test
    fun `Invalid Email No Username, Returns False`() = assertFalse(emailValidator("@email.com").isValid)

    @Test
    fun `Empty String Email, Returns False`() = assertFalse(emailValidator("").isValid)

    @Test
    fun `Email is Null, Returns False`() = assertFalse(emailValidator(null).isValid)
}