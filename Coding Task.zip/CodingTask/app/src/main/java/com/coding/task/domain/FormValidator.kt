package com.coding.task.domain

interface FormValidator<T> {
    operator fun invoke(data: T): ValidationResult
}
