package com.coding.task.viewmodel

import androidx.datastore.core.DataStore
import androidx.lifecycle.MutableLiveData
import com.coding.task.domain.BirthdayValidator
import com.coding.task.domain.EmailValidator
import com.coding.task.domain.ErrorEvent
import com.coding.task.domain.ErrorEvent.*
import com.coding.task.domain.NameValidator
import com.coding.task.model.User
import com.coding.task.utils.Event
import com.coding.task.utils.toPrettyDate
import java.util.*

class RegistrationViewModel(
    private val userRepository: DataStore<User>,
    private val nameValidator: NameValidator,
    private val emailValidator: EmailValidator,
    private val birthdayValidator: BirthdayValidator
) : BaseViewModel() {
    var name: String = ""
    var email: String = ""
    var dateOfBirth: Long? = null
    val birthdayChanged = MutableLiveData<String>()
    var registerSuccess = MutableLiveData<Event<Unit>>()
    var registerFail = MutableLiveData<Event<ErrorEvent>>()

    fun register() {
        val isValidName = nameValidator(name)
        val isValidEmail = emailValidator(email)
        val isValidBirthday = birthdayValidator(dateOfBirth)
        val validationResults = listOf(isValidName, isValidEmail, isValidBirthday)
        val isValid = validationResults.all { it.isValid }
        if (isValid) {
            launch {
                userRepository.updateData { it.copy(name = name, email = email, dateOfBirth = dateOfBirth) }
                registerSuccess.postValue(Event(Unit))
            }
        } else {
            registerFail.value = Event(NameError(isValidName))
            registerFail.value = Event(EmailError(isValidEmail))
            registerFail.value = Event(BirthdayError(isValidBirthday))
        }
    }

    fun setBirthday(date: Long?) {
        dateOfBirth = date
        birthdayChanged.postValue(dateOfBirth?.let { Date(it).toPrettyDate() })
    }
}