package com.coding.task.utils

open class Event<out T>(private val content: T) {
    private var wasObserved = false
    fun getContentIfNotHandled(): T? {
        return if (wasObserved) {
            null
        } else {
            wasObserved = true
            content
        }
    }

    fun getContent(): T = content
}