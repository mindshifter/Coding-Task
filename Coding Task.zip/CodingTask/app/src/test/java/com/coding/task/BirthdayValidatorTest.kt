package com.coding.task

import com.coding.task.domain.BirthdayValidator
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.util.*

class BirthdayValidatorTest {
    private lateinit var birthdayValidator: BirthdayValidator
    private lateinit var validDate: Date
    private lateinit var invalidDate: Date

    @Before
    fun setUp() {
        birthdayValidator = BirthdayValidator()
        validDate = Calendar.getInstance(TimeZone.getTimeZone("GMT")).apply { set(1984, 8, 30) }.time
        invalidDate = Date(System.currentTimeMillis())
    }

    @Test
    fun `Birthday between (Jan 1, 1900 and December 31 2019) Returns False`() = assertTrue(birthdayValidator(validDate.time).isValid)

    @Test
    fun `Birthday after (December 31 2019), Returns False`() = assertFalse(birthdayValidator(invalidDate.time).isValid)

    @Test
    fun `Birthday is Null Returns False`() = assertFalse(birthdayValidator(null).isValid)
}