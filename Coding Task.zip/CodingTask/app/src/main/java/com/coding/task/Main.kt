package com.coding.task

import android.app.Application
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin

class Main : Application() {
    override fun onCreate() {
        super.onCreate()
        //Koin DI Initialization
        startKoin {
            androidLogger()
            androidContext(this@Main)
            modules(listOf(singletonModule, viewModelModule))
        }
    }
}