package com.coding.task.viewmodel

import androidx.datastore.core.DataStore
import androidx.lifecycle.asLiveData
import androidx.lifecycle.distinctUntilChanged
import com.coding.task.model.User

class ConfirmationViewModel(
    userRepository: DataStore<User>
) : BaseViewModel() {
    val user = userRepository.data.asLiveData().distinctUntilChanged()
}