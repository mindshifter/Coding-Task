package com.coding.task

import android.content.Context
import androidx.datastore.core.DataStoreFactory
import androidx.datastore.dataStoreFile
import com.coding.task.domain.BirthdayValidator
import com.coding.task.domain.EmailValidator
import com.coding.task.domain.NameValidator
import com.coding.task.model.RegistrationModelSerializer
import com.coding.task.viewmodel.ConfirmationViewModel
import com.coding.task.viewmodel.RegistrationViewModel
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val singletonModule = module {
    /** From docs
     * Creates a property delegate for a single process DataStore. This should only be called once
     * in a file (at the top level), and all usages of the DataStore should use a reference the same
     * Instance. The receiver type for the property delegate must be an instance of [Context].
     * This should only be used from a single application in a single classloader in a single process.
     */
    single {
        DataStoreFactory.create(serializer = RegistrationModelSerializer,
            produceFile = { androidContext().dataStoreFile("user.json") })
    }

    //Single definitions
    single { NameValidator() }
    single { EmailValidator() }
    single { BirthdayValidator() }
}

val viewModelModule = module {
    //ViewModel definition
    viewModel { RegistrationViewModel(get(), get(), get(), get()) }
    viewModel { ConfirmationViewModel(get()) }
}


