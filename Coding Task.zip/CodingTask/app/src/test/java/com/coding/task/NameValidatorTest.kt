package com.coding.task

import com.coding.task.domain.NameValidator
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class NameValidatorTest {
    private lateinit var nameValidator: NameValidator

    @Before
    fun setUp() {
        nameValidator = NameValidator()
    }

    @Test
    fun `Name is one letter, Returns False`() = assertFalse(nameValidator("a").isValid)

    @Test
    fun `Name with 2 letters, Returns True`() = assertTrue(nameValidator("aa").isValid)

    @Test
    fun `Name is null, Returns False`() = assertFalse(nameValidator(null).isValid)
}