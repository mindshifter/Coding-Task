package com.coding.task.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.coding.task.databinding.FragmentConfirmationBinding
import com.coding.task.utils.toPrettyDate
import com.coding.task.viewmodel.ConfirmationViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.util.*

class ConfirmationFragment : BaseFragment<FragmentConfirmationBinding>() {
    override val bindingInflater: (LayoutInflater, ViewGroup?, Boolean) -> FragmentConfirmationBinding = FragmentConfirmationBinding::inflate
    private val viewModel: ConfirmationViewModel by viewModel()
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.user observe {
            with(binding) {
                userName.text = it.name
                userEmail.text = it.email
                userBirthday.text = it.dateOfBirth?.let { Date(it).toPrettyDate() }
            }
        }
    }
}