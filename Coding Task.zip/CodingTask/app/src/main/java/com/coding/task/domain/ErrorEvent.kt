package com.coding.task.domain

sealed class ErrorEvent(val result: ValidationResult) {
    class NameError(result: ValidationResult) : ErrorEvent(result)
    class EmailError(result: ValidationResult) : ErrorEvent(result)
    class BirthdayError(result: ValidationResult) : ErrorEvent(result)
}