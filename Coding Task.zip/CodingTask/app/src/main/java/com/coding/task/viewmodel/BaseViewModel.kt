package com.coding.task.viewmodel

import androidx.lifecycle.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

abstract class BaseViewModel : ViewModel(), LifecycleEventObserver {
    fun <T> launch(block: suspend CoroutineScope.() -> T): Job = viewModelScope.launch { block() }

    override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
        if (event == Lifecycle.Event.ON_DESTROY) source.lifecycle.removeObserver(this)
    }
}
