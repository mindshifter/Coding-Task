package com.coding.task.utils

import com.coding.task.domain.BirthdayValidator
import com.google.android.material.datepicker.CalendarConstraints.DateValidator
import kotlinx.parcelize.Parcelize

@Parcelize
class MaterialDatePickerBirthdayDateValidator : DateValidator {
    override fun isValid(date: Long): Boolean = date in BirthdayValidator.dateFrom.time..BirthdayValidator.dateTo.time
}